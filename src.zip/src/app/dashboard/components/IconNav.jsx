const IconNav = () => {
    return (
        <div>
            Enter
        </div>
    );
}

export default IconNav;