export default function Layout({children}) {
    return (
        <section>
            {children}
        </section>
    );
}