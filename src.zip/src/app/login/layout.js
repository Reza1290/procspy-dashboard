

const LoginLayout = ({ children }) => {
    return <section>
        {children}
    </section>
}


export default LoginLayout